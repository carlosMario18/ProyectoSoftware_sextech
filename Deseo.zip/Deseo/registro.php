<?php
// Conexión a la base de datos
$host = 'localhost';
$db   = 'registro';  // Reemplaza con el nombre de tu base de datos
$user = 'root';  // Reemplaza con tu usuario de MySQL
$pass = 'admin';  // Reemplaza con tu contraseña de MySQL
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

try {
    $pdo = new PDO($dsn, $user, $pass);
} catch (PDOException $e) {
    throw new PDOException($e->getMessage(), (int)$e->getCode());
}

// Registro de usuarios
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $usuario = $_POST['usuario'];
    $email = $_POST['email'];
    $contraseña = password_hash($_POST['contraseña'], PASSWORD_DEFAULT);  // Encripta la contraseña

    $sql = "INSERT INTO usuarios (nombre, apellidos, usuario, email, contraseña) VALUES (?, ?, ?, ?, ?)";
    $stmt= $pdo->prepare($sql);
    $stmt->execute([$nombre, $apellidos, $usuario, $email, $contraseña]);

    echo "Usuario registrado con éxito!";
}
?>