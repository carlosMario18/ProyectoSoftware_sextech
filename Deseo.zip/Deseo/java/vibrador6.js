let currentIndex = 0;
const images = [
    '/img/juguetes/vibrador6/jugue5.jpg',
    '/img/juguetes/vibrador6/88129.jpg',
    '/img/juguetes/vibrador6/durex-play-diablillo.jpg'

];

function changeImage(index) {
    currentIndex = index;
    document.getElementById("main-image").src = images[currentIndex];
    updateButtons();
}

function prevImage() {
    if (currentIndex > 0) {
        currentIndex--;
        document.getElementById("main-image").src = images[currentIndex];
        updateButtons();
    }
}

function nextImage() {
    if (currentIndex < images.length - 1) {
        currentIndex++;
        document.getElementById("main-image").src = images[currentIndex];
        updateButtons();
    }
}

function updateButtons() {
    document.getElementById("prev-btn").disabled = currentIndex === 0;
    document.getElementById("next-btn").disabled = currentIndex === images.length - 1;
}

// Inicializa los botones
updateButtons();
