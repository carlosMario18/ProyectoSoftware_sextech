let currentIndex = 0;
const images = [
   
    '/img/dh/dhs/s-l640.jpg',
    '/img/dh/dhs/617ACKrlhWL._AC_UF350,350_QL80_.jpg'
];

function changeImage(index) {
    currentIndex = index;
    document.getElementById("main-image").src = images[currentIndex];
    updateButtons();
}

function prevImage() {
    if (currentIndex > 0) {
        currentIndex--;
        document.getElementById("main-image").src = images[currentIndex];
        updateButtons();
    }
}

function nextImage() {
    if (currentIndex < images.length - 1) {
        currentIndex++;
        document.getElementById("main-image").src = images[currentIndex];
        updateButtons();
    }
}

function updateButtons() {
    document.getElementById("prev-btn").disabled = currentIndex === 0;
    document.getElementById("next-btn").disabled = currentIndex === images.length - 1;
}

// Inicializa los botones
updateButtons();
