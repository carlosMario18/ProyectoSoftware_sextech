let currentIndex = 0;
const images = [
   
    '/img/juguetes/vibrador2/rosa.jpg',
    '/img/juguetes/vibrador2/3949_lovense-lush-3_es.jpg',
    '/img/juguetes/vibrador2/615dOVQBW9L.jpg'
];

function changeImage(index) {
    currentIndex = index;
    document.getElementById("main-image").src = images[currentIndex];
    updateButtons();
}

function prevImage() {
    if (currentIndex > 0) {
        currentIndex--;
        document.getElementById("main-image").src = images[currentIndex];
        updateButtons();
    }
}

function nextImage() {
    if (currentIndex < images.length - 1) {
        currentIndex++;
        document.getElementById("main-image").src = images[currentIndex];
        updateButtons();
    }
}

function updateButtons() {
    document.getElementById("prev-btn").disabled = currentIndex === 0;
    document.getElementById("next-btn").disabled = currentIndex === images.length - 1;
}

// Inicializa los botones
updateButtons();
