let currentIndex = 0;
const images = [
   
    '/img/juguetes/vibrador1/LOVENSE-domi-01.jpg',
    '/img/juguetes/vibrador1/vibrador-domi-hitachi-lovense-interactivo-app1-77c6cb0e4911505d5016029906927880-640-0.png',
    '/img/juguetes/vibrador1/vibrador1.gif',
    '/img/juguetes/vibrador1/cajalovense.jpg'
];

function changeImage(index) {
    currentIndex = index;
    document.getElementById("main-image").src = images[currentIndex];
    updateButtons();
}

function prevImage() {
    if (currentIndex > 0) {
        currentIndex--;
        document.getElementById("main-image").src = images[currentIndex];
        updateButtons();
    }
}

function nextImage() {
    if (currentIndex < images.length - 1) {
        currentIndex++;
        document.getElementById("main-image").src = images[currentIndex];
        updateButtons();
    }
}

function updateButtons() {
    document.getElementById("prev-btn").disabled = currentIndex === 0;
    document.getElementById("next-btn").disabled = currentIndex === images.length - 1;
}

// Inicializa los botones
updateButtons();
